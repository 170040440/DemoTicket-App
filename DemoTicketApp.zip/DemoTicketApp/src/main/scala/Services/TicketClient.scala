package Services

object TicketClient {
  /*
    Attribute for TicketClient
      - allTickets : List of all ticket objects created.
   */

  def AssignTask(empId: String): Unit = {
    /*
      This method should create a new ticket with random ticketId and assign it to
      the user with this empId. Ticket state should be CREATED and priority should be 1.
      After creation of every new ticket, add it to allTickets List.
     */
  }

}
