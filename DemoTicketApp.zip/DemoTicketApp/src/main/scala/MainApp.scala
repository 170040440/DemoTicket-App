object MainApp extends App {
  val employeeData1 = "Rajesh 123 Developer"
  val empoyeeData2 = "Suresh 345 Manager"

  /*
      Create objects employee1 and employee2 using the attributes from above variable.
      The employee data is in the form <Name>+ " " + <empId> + " " + <role>
   */

  /*
      Perform below operations on both employees
      1. Assign a ticket to employee1
      2. Print list of all tickets
      3. Reassign same ticket to employee2
      4. Print list of all tickets
      5. Unassign ticket from employee2
      6. Assign another ticket to employee1
      7. Print list of all tickets
   */


}
