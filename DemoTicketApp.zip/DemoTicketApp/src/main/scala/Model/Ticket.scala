package Model

class Ticket {
  /*
      Attributes for class Ticket:
        - ticketId : String
        - state : String
        - priority : Number
        - assignee : String
   */

  def UnAssign: Unit ={
    /*
      This method should change the assignee ticket to null.
     */
  }

  def ReAssign(empId: String): Unit = {
    /*
      This method should change the assignee ticket to the user with the given empId.
     */
  }
}
