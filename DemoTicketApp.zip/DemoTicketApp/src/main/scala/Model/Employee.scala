package Model

class Employee {
  /*
      Attributes for class Employee:
        - mame : String
        - empId : String
        - role : String
   */
}
